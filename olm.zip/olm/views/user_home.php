<!DOCTYPE html>
<html>
<head>
	<?php
	//<head></head>
	include('includes/head.inc');
	?>
</head>
<body>
	<?php
	//<head></head>
	include('includes/header.inc');

	?>
	<div class="welcome-bar"><div class="welcome-msg">Welcome <?php echo olm_session_get_name(); ?></div></div>
	<div class="user-section col-3">
		<div class="user-section-title">Search books</div>
		<div class="user-section-body">
			<a href="/m140163cs/olm/control/user_search.php#bytitle">
				<div class="user-sub-section">
				<div class="thumbnail searchby"><img src="/m140163cs/olm/assets/images/Books-1-icon.png" /></div>
				<div class="thumbnail-caption">Search by Title</div>
			</div></a>
			<a href="/m140163cs/olm/control/user_search.php#byauthor">
			<div class="user-sub-section">
				<div class="thumbnail searchby"><img src="/m140163cs/olm/assets/images/author-icon.png" /></div>
				<div class="thumbnail-caption">Search by Author</div>
			</div>
			</a>
			<a href="/m140163cs/olm/control/user_search.php#bycategory">
			<div class="user-sub-section">
				<div class="thumbnail searchby"><img src="/m140163cs/olm/assets/images/Books-2-icon.png" /></div>
				<div class="thumbnail-caption">Search by Category</div>
			</div>
			</a>
		</div>
	</div>

	<div class="user-section">
		<a href="control/check_status.php?">Check status</a>
	</div>

	<div class="footer">
		<?php include('includes/footer.inc'); ?>
	</div>	
</body>
</html>