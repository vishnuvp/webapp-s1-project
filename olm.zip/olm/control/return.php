<!DOCTYPE html>
<html>
<head>
	<?php
	//<head></head>
	include('../includes/head.inc');

	?>
</head>
<body>
<?php
include('../includes/header.inc');
?>

<?php 
if($_SERVER['REQUEST_METHOD'] == 'POST') {

	$user = new Admin;
	$bid = substr($_POST['bid'], 5);
	$flag = $user->return_book($bid); 
	
	echo set_status($flag['msg'],$flag['status']);
	

}
else {
?>
<div class="form-container" id="return-add-form-container">
		<form name="return-add-form" method="post" action="return.php">
	
			<div class="input-container inline-label">
				<label for="name">Book ID</label>:<input name="bid" type="text" value="<?php echo $_CONF['book_prefix'].convert_4digits($_GET['bid']); ?>"/>
			</div>
			
			<div class="input-container submit-btn">
				<input name="submit" type="submit" value="Return"/>
			</div>
		</form>
</div>
<?php }

?>
<div class="footer">
			<?php include('../includes/footer.inc'); ?>
	</div>	
</body>
</html>