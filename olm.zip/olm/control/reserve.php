<!DOCTYPE html>
<html>
<head>
	<?php
	//<head></head>
	include('../includes/head.inc');

	?>
</head>
<body>
<?php
include('../includes/header.inc');
?>

<?php 
if($_SERVER['REQUEST_METHOD'] == 'POST') {

	$user = new User;
	$bid = substr($_POST['bid'], 5);
	$flag = $user->reserve_book($bid, $_POST['uid']); 
	
	echo set_status($flag['msg'],$flag['status']);
	

}
else {
?>
<div class="form-container" id="reserve-add-form-container">
		<form name="reserve-add-form" method="post" action="reserve.php">
	
			<div class="input-container inline-label">
				<label for="name">Book ID</label>:<input name="bid" type="text" value="<?php echo $_CONF['book_prefix'].convert_4digits($_GET['bid']); ?>"/>
			</div>
			<div class="input-container inline-label">
				<label for="name">User ID</label>:<input name="uid" type="text" value="<?php echo olm_session_get_user(); ?>"/>
			</div>
			<div class="input-container submit-btn">
				<input name="submit" type="submit" value="Reserve"/>
			</div>
		</form>
</div>
<?php }

?>
<div class="footer">
			<?php include('../includes/footer.inc'); ?>
	</div>	
</body>
</html>