<?php
require(__DIR__ . "/../includes/db.class.inc");
require('fpdf.php');


$pdf = new FPDF();


//$pdf->SetFont('dejavusans', '', 12, '', true);

// Add a page
// This method has several options, check the source code documentation for more information.
$pdf->SetFillColor(255, 255, 255);
$pdf->AddPage();


//$pdf->SetFont('', 'B');
$pdf->Cell('0', 6, 'USERS LIST', '', 1, 'C', 1);

$pdf->SetFillColor(224, 235, 255);
$pdf->SetTextColor(0,0,0);
$pdf->SetDrawColor(224, 235, 255);
$pdf->SetLineWidth(0.3);
$pdf->Ln();
$pdf->Cell('50', 6, 'User ID', '0', 0, 'C', 1);
$pdf->Cell('0', 6, 'Name', '0', 0, 'C', 1);
$pdf->Ln();
$pdf->SetFillColor(224, 235, 255);
$pdf->SetTextColor(0,0,0);
$pdf->SetDrawColor(224, 235, 255);
$pdf->SetLineWidth(0.3);

$db_connection = new DBConnection;
$db_connection->connect();
$result = $db_connection->query('user', 'uid,name', null,null,null);
//print_r($result);
$db_connection->disconnect();
/*foreach($result as $value) {
  
  $pdf->Cell('50', 6, $value['uid'], '1', 0, 'C', 0);
  $pdf->Cell('0', 6, $value['name'], '1', 0, 'C', 0);
  $pdf->Ln();
    
}*/
//print_r($pdf);

// Close and output PDF document
// This method has several options, check the source code documentation for more information.
$pdf->Output();

?>