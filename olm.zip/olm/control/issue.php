<!DOCTYPE html>
<html>
<head>
	<?php
	//<head></head>
	include('../includes/head.inc');

	?>
</head>
<body>
<?php
include('../includes/header.inc');
?>

<?php 
if($_SERVER['REQUEST_METHOD'] == 'POST') {

	$admin = new Admin;
	$bid = substr($_POST['bid'], 5);
	$flag = $admin->issue_book($bid, $_POST['uid']); 
	
	echo set_status($flag['msg'],$flag['status']);
	

}
else {
?>
<div class="form-container" id="issue-add-form-container">
		<form name="issue-add-form" method="post" action="issue.php">
	
			<div class="input-container inline-label">
				<label for="name">Book ID</label>:<input name="bid" type="text" value="<?php echo $_CONF['book_prefix'].convert_4digits($_GET['bid']); ?>"/>
			</div>
			<div class="input-container inline-label">
				<label for="name">User ID</label>:<input name="uid" type="text" />
			</div>
			<div class="input-container submit-btn">
				<input name="submit" type="submit" value="Issue"/>
			</div>
		</form>
</div>
<?php }

?>
<div class="footer">
			<?php include('../includes/footer.inc'); ?>
	</div>	
</body>
</html>