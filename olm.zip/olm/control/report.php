<!DOCTYPE html>
<html>
<head>
	<?php
	//<head></head>
	include('../includes/head.inc');
	?>
</head>
<body>
	<?php
	//<head></head>
	include('../includes/header.inc');

	?>
	<div class="user-section col-3">
		<div class="user-section-title">Reports</div>
		<div class="user-section-body">
			<a href="/m140163cs/olm/control/user_report.php" target="_blank">
				<div class="user-sub-section">
				<div class="thumbnail searchby"><img src="/m140163cs/olm/assets/images/pdf_icon.png" /></div>
				<div class="thumbnail-caption">User List</div>
			</div></a>
			<a href="/m140163cs/olm/control/book_report.php" target="_blank">
			<div class="user-sub-section">
				<div class="thumbnail searchby"><img src="/m140163cs/olm/assets/images/pdf_icon.png" /></div>
				<div class="thumbnail-caption">Books Status Report</div>
			</div>
			</a>
			<a href="/m140163cs/olm/control/overdue_report.php" target="_blank">
			<div class="user-sub-section">
				<div class="thumbnail searchby"><img src="/m140163cs/olm/assets/images/pdf_icon.png" /></div>
				<div class="thumbnail-caption">Overdue Report</div>
			</div>
			</a>
		</div>
	</div>

	
	<div class="footer">
		<?php include('../includes/footer.inc'); ?>
	</div>	
</body>
</html>